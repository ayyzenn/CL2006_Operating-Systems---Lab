#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

int main()
{
    FILE *fpointer,*fpointer2;

    int factorial=0;   
    int n, i;
    int fact = 1;

    printf("Enter an integer: ");  
    scanf("%d", &factorial);

    int pid=fork();

    if (pid==0)
    {
        fpointer2=fopen("file.txt","r");
        int *num;
        fscanf(fpointer2,"%d",num);

        int val=*num;
        for (i = 1; i <= val; i++) 
        {
            fact *= i;
        }
        printf("Factorial of number is %d\n",fact);
        fclose(fpointer2);
    }
    else 
    {
        fpointer = fopen("file.txt","w");

        fprintf(fpointer,"%d",factorial);
        fclose(fpointer);
    }

    return 0;
}

