#include<stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
int main(int argc, char *argv[])
{ 
    int pfd[2];
    char c;
    char aString[20]; 
    FILE *fpointer,*fpointer2;

    pipe(pfd);

    int pid = fork();
    
    if (pid == 0)
    {
        fpointer2 = fopen("copy.txt", "w");

        if (fpointer2 == NULL)
        {

            printf("Error! The file does not exist.\n");
            exit(0);
        }
       
        read(pfd[0], aString, 5);

        fputs(aString,fpointer2);
        fclose(fpointer2);

    }
    else
    {

        fpointer = fopen("file.txt", "r");
        if (fpointer == NULL)
        {

            printf("Error! The file does not exist.\n");
            exit(0);
        }

        do
        {
            c=fgetc(fpointer);
            write(pfd[1], (void *)&c, 1);

        } while (c!=EOF);
        
       
        fclose(fpointer);
    }

    return 0;
}