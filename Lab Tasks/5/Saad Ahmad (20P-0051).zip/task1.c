#include<stdio.h>
#include<unistd.h>

int main() 
{
   int pipe1[2], pipe2[2];
   
   int pid;
   char pipe1message[20];
   char pipe2message[20];
   
   char readmessage[20];

   pipe(pipe1);
   pipe(pipe2);
    
    printf("P1: ");
    scanf("%s",pipe1message);
    printf("P2: ");
    scanf("%s",pipe2message);
   
    

   pid = fork();
   while (1)
   {
       

      if (pid != 0) // Parent process 
      {
         close(pipe1[0]); // Close pipe1 read side
         close(pipe2[1]); // Close pipe2 write side
      
         printf("In Parent: Writing to pipe 1  %s\n", pipe1message);
         write(pipe1[1], pipe1message, sizeof(pipe1message));
         sleep(1);
         read(pipe2[0], readmessage, sizeof(readmessage));
         printf("In Parent: Reading from pipe 2  %s\n", readmessage);
      }

      else 
      { 
         //child process 
         close(pipe1[1]); // Close pipe1 write side
         close(pipe2[0]); // Close pipe2 read side
         
         read(pipe1[0], readmessage, sizeof(readmessage));
         printf("In Child: Reading from pipe 1  %s\n", readmessage);
         printf("In Child: Writing to pipe 2  %s\n", pipe2message);
         sleep(1);
         write(pipe2[1], pipe2message, sizeof(pipe2message));
      }

   }
   return 0;
}